//@Author Mayank Y.
package com.SMSbilling.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SMSbilling.Service.CustomerService;

@RestController
@Configuration
@EnableScheduling
@RequestMapping("/sms")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@GetMapping("/")
	public String Run() {
		return "Running...";
	}

//To get all The Customer details
	@GetMapping(path = "/getAll", produces = { "application/json" })
	public ResponseEntity<?> getAll() {
		return customerService.getall();
	}

//To Create new Customer
	@PostMapping(path = "/create", produces = { "application/json" })
	public ResponseEntity<?> create(@RequestParam String name, String plan, String senderId) {
		return customerService.create(name, plan, senderId);
	}

//	To Send Sms (List of numbers with Comma seperated)
	@PostMapping(path = "/sendSms", produces = { "application/json" })
	public ResponseEntity<?> sendSms(@RequestParam String mobile, String message, long uId) {
		return customerService.SendSms(mobile, message, uId);
	}

// Auto Generate Bill in the end of every month 
	@Scheduled(cron = "59 59 23 L * ?")
	@GetMapping("/bill")
	public ResponseEntity<?> generateBill() {
		return customerService.generateBill();
	}

//Generate bill for a Customer 	
	@GetMapping("/bill/{uId}")
	public ResponseEntity<?> generateBill(@PathVariable long uId) {
		return customerService.generateBillById(uId);
	}
}
