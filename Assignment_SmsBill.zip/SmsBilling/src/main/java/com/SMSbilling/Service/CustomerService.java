package com.SMSbilling.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.SMSbilling.Entity.Customer;
import com.SMSbilling.Repository.CustomerRepo;
import com.SMSbilling.utility.Plans;

@Service
@PropertySource("classpath:application.properties")
public class CustomerService {

	@Value("${key}")
	String key;

	@Autowired
	CustomerRepo customerRepo;

	public ResponseEntity<?> getall() {
		List<Customer> customers = customerRepo.findAll();
		return new ResponseEntity<>(customers, HttpStatus.OK);

	}

	public ResponseEntity<?> create(String name, String plan, String senderId) {
		Customer customer = new Customer(name, plan, 0L, LocalDate.now(), 1, senderId, "GeneratedSMSTemplateID");
		customerRepo.save(customer);
		List<Customer> customers = customerRepo.findAll();
		return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	public ResponseEntity<String> SendSms(String numbers, String message, long uId) {

		List<String> mobiles = List.of(numbers.split(","));

		try {
			Customer customer = customerRepo.findById(uId).get();
			for (String mobile : mobiles) {
				String urlString = "http://api.msg91.com/api/sendotp.php?authkey=" + key + "&mobile=" + mobile
						+ "&message=" + message + "&sender=" + customer.getSenderId() + "&DLT_TE_ID="
						+ customer.getTemplateId();
				URL url = new URL(urlString);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");

				if (conn.getResponseCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
				}
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				String output;
				System.out.println("Output from Server .... \n");
				while ((output = br.readLine()) != null) {
					System.out.println(output);
				}
				conn.disconnect();
			}
			customer.setSmsCount(customer.getSmsCount() + mobiles.size());
			customerRepo.save(customer);
			return new ResponseEntity<>("Sms sent", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("Sms sent Failed", HttpStatus.BAD_GATEWAY);
		}
	}

	public ResponseEntity<?> generateBill() {

		List<Map> bills = new ArrayList();
		List<Customer> customersList = customerRepo.findAll();
		try {
			for (Customer customer : customersList) {
				bills.add(calcualteBill(customer));
			}
			return new ResponseEntity<>(bills, HttpStatus.OK);
		} catch (Exception e) {
			System.err.println(e);
			return new ResponseEntity<>("Bill Generate Failed", HttpStatus.BAD_REQUEST);
		}
	}

	public ResponseEntity<?> generateBillById(long uId) {
		Map map = calcualteBill(customerRepo.findById(uId).get());
		return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
	}

	private Map calcualteBill(Customer customer) {
		String plan = customer.getPlan();
		double FinalAmount = 0;

		switch (plan) {
		case "Basic":
			FinalAmount = customer.getSmsCount() > Plans.BasicLimit
					? (customer.getSmsCount() - Plans.BasicLimit) * Plans.BasicAmount
					: 0;
			break;
		case "Silver":
			FinalAmount = customer.getSmsCount() > Plans.BasicLimit
					? (customer.getSmsCount() - Plans.SilverLimit) * Plans.SilverAmount
					: 0;
			break;
		case "Gold":

			if (customer.getSmsCount() > Plans.DiscountGoldLimit)
				FinalAmount = ((customer.getSmsCount() - Plans.DiscountGoldLimit) * Plans.DiscountGoldAmount)
						+ (((customer.getSmsCount() - Plans.GoldLimit)
								- (customer.getSmsCount() - Plans.DiscountGoldLimit)) * Plans.GoldAmount);
			
			else if (customer.getSmsCount() <= Plans.DiscountGoldLimit && customer.getSmsCount() > 1000)
				FinalAmount = (customer.getSmsCount() - Plans.GoldLimit) * Plans.GoldAmount;
			break;
		}

		Map<String, String> map = new HashMap<>();
		map.put("CustomerName", customer.getName());
		map.put("plan", customer.getPlan());
		map.put("SMS_Count", customer.getSmsCount().toString());
		map.put("Amount_To_Be_Pay", "$ " + FinalAmount);
		return map;
	}

}
