package com.SMSbilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsBillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsBillingApplication.class, args);
	}

}
