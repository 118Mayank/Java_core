package com.SMSbilling.utility;

public class Plans {
	
	public static final double BasicAmount=0.001;
	public static final double SilverAmount=0.002;
	public static final double GoldAmount=0.003;
	public static final double DiscountGoldAmount=0.0005;
	
	public static final int BasicLimit=0;
	public static final int SilverLimit=100;
	public static final int GoldLimit=1000;
	public static final int DiscountGoldLimit=100000;
}
