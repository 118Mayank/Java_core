//@Author Mayank Yadav (8839949559)

package com.train.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Train {

	static List<String> TrainA = Arrays.asList("CHENNAI(CHN)-0", "SALEM(SLM)-350", "BANGALORE (BLR)-550",
			"KURNOOL(KRN)-900", "HYDERABAD(HYB)-1200", "NAGPUR(NGP)-1600", "ITARSI(ITJ)-1900", "BHOPAL(BPL)-2000",
			"AGRA (AGA)-2500", "NEW DELHI(NDL)-2700");

	static List<String> TrainB = Arrays.asList("TRIVANDRUM(TVC)-0", "SHORANUR(SRR)-300", "MANGALORE(MAQ)-600",
			"MADGAON(MAO)-1000", "PUNE(PNE)-1400", "HYDERABAD(HYB)-2000", "NAGPUR(NGP)-2400", "ITARSI(ITJ)-2700",
			"BHOPAL(BPL)-2800", "PATNA(PTA)-3800", "NEW JALPAIGURI(NJP)-4200", "GUWAHATI(GHY)-4700");

	public static void main(String[] args) throws IOException {
//Change File Name From Here
		File file = new File("./TrainList_1.txt");
//Change Current station from Here
		String defaultStation = "HYB";

		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			List<Integer> distances_A = new ArrayList<>();
			List<Integer> distances_B = new ArrayList<>();
			List<Integer> distances = new ArrayList<>();
			String st;
			while ((st = br.readLine()) != null) {
				List<String> stationCodeList = Arrays.asList(st.split(" "));

				int defaultDistanceA = AtrainCodeToDistance(defaultStation);
				int defaultDistanceB = BtrainCodeToDistance(defaultStation);
				for (int i = 2; i < stationCodeList.size(); i++) {
					if (stationCodeList.contains("TRAIN_A")
							&& AtrainCodeToDistance(stationCodeList.get(i)) >= defaultDistanceA) {
						distances_A.add(AtrainCodeToDistance(stationCodeList.get(i)));

					} else if (stationCodeList.contains("TRAIN_B")
							&& BtrainCodeToDistance(stationCodeList.get(i)) >= defaultDistanceB) {
						distances_B.add(BtrainCodeToDistance(stationCodeList.get(i)));

					}
				}

			}
			distances.addAll(distances_A);
			distances.addAll(distances_B);

			Collections.sort(distances_A);
			Collections.sort(distances_B);
			Collections.sort(distances);
//			Collections.reverse(distances_A);
			Collections.reverse(distances_B);
			Collections.reverse(distances);

			List<String> train_A = distances_A.stream().map(distance_A -> AtrainDistanceToCode(distance_A))
					.collect(Collectors.toList());
			train_A.add(0, "TRAIN_A");
			train_A.add(1, "ENGINE");

			List<String> train_B = distances_B.stream().map(distance_B -> BtrainDistanceToCode(distance_B))
					.collect(Collectors.toList());
			train_B.add(0, "TRAIN_B");
			train_B.add(1, "ENGINE");

			List<String> train_AB = distances.stream().map(distance -> TrainDistanceToCode(distance))
					.collect(Collectors.toList());
			train_AB.add(0, "TRAIN_AB");
			train_AB.add(1, "ENGINE");
			train_AB.add(2, "ENGINE");

			System.out.println("\033[0;1m" + "ARRIVAL " + "\033[0;0m" + train_A + "\n\033[0;1m" + "ARRIVAL \033[0;0m"
					+ train_B + "\n\033[0;1m" + "DEPARTURE \033[0;0m" + train_AB);
		}
	}

	public static int AtrainCodeToDistance(String sCode) {
		int defaultDistance = 0;
		for (int k = 0; k < TrainA.size(); k++) {
			if (TrainA.get(k).contains("(" + sCode + ")")) {
				defaultDistance = Integer
						.parseInt(TrainA.get(k).subSequence(TrainA.get(k).indexOf("-") + 1, TrainA.get(k).length())
								.toString().replaceAll("\\s", ""));
			}
		}
		return defaultDistance;
	}

	public static int BtrainCodeToDistance(String sCode) {
		int defaultDistance = 0;
		for (int k = 0; k < TrainB.size(); k++) {
			if (TrainB.get(k).contains("(" + sCode + ")")) {
				defaultDistance = Integer
						.parseInt(TrainB.get(k).subSequence(TrainB.get(k).indexOf("-") + 1, TrainB.get(k).length())
								.toString().replaceAll("\\s", ""));
			}
		}
		return defaultDistance;
	}

	public static String AtrainDistanceToCode(int distance) {
		String code = "";
		for (int k = 0; k < TrainA.size(); k++) {
			if (TrainA.get(k).contains(distance + "")) {
				code = TrainA.get(k).substring(TrainA.get(k).indexOf("(") + 1, TrainA.get(k).indexOf(")"));
				break;
			}
		}
		return code;
	}

	public static String BtrainDistanceToCode(int distance) {
		String code = "";
		for (int k = 0; k < TrainB.size(); k++) {
			if (TrainB.get(k).contains(distance + "")) {
				code = TrainB.get(k).substring(TrainB.get(k).indexOf("(") + 1, TrainB.get(k).indexOf(")"));
				break;
			}
		}
		return code;
	}

//	public static int TrainCodeToDistance(String sCode) {
//		int defaultDistance = 0;
//		List<String> Train = new ArrayList<>();
//		Train.addAll(TrainA);
//		Train.addAll(TrainB);
//		for (int k = 0; k < Train.size(); k++) {
//			if (Train.get(k).contains("(" + sCode + ")")) {
//				defaultDistance = Integer
//						.parseInt(Train.get(k).subSequence(Train.get(k).indexOf("-") + 1, Train.get(k).length())
//								.toString().replaceAll("\\s", ""));
//			}
//		}
//		return defaultDistance;
//	}
//

	public static String TrainDistanceToCode(int distance) {
		String code = "";
		List<String> Train = new ArrayList<>();
		Train.addAll(TrainA);
		Train.addAll(TrainB);
		for (int k = 0; k < Train.size(); k++) {
			if (Train.get(k).contains(distance + "")) {
				code = Train.get(k).substring(Train.get(k).indexOf("(") + 1, Train.get(k).indexOf(")"));
				break;
			}
		}
		return code;
	}

}
