package com.example.Train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwoTrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
